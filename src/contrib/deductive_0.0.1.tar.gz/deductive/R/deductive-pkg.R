#' Deductive Data Correction and Imputation
#' 
#' @name deductive
#' @doctype package
#' @import methods
#' @import lintools
#' @import validate
#' @useDynLib deductive
{}


