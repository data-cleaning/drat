



#ifndef rspa_Rsc
#define rspa_Rsc
#include "sparseConstraints.h"


void R_sc_del( SEXP );


SEXP R_print_sc( SEXP, SEXP, SEXP );

SEXP R_sc_from_matrix( SEXP, SEXP, SEXP, SEXP );

#endif
