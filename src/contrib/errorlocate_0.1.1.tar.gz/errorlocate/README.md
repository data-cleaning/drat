[![Build Status](https://travis-ci.org/data-cleaning/errorlocate.svg)](https://travis-ci.org/data-cleaning/errorlocate)
[![CRAN](http://www.r-pkg.org/badges/version/errorlocate)](http://cran.r-project.org/package=errorlocate/)
[![Downloads](http://cranlogs.r-pkg.org/badges/errorlocate)](http://www.r-pkg.org/pkg/errorlocate) 
[![Coverage Status](https://coveralls.io/repos/data-cleaning/errorlocate/badge.svg?branch=master&service=github)](https://coveralls.io/github/data-cleaning/errorlocate?branch=master)
# Error localization

Find erronous fields based on validation rules from `validate`

# naming options

Logging:

- will be event-based





