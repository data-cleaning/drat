## ----eval=FALSE----------------------------------------------------------
#  library(dcmodify)
#  library(magrittr)
#  iris %<>% modify_so( if(Sepal.Width > 4 ) Sepal.Width <- 4 )

## ------------------------------------------------------------------------
data("retailers", package="validate")
head(retailers[-(1:2)],3)

## ------------------------------------------------------------------------
library(dcmodify)
m <- modifier(
  if (other.rev < 0) other.rev <- -1 * other.rev
  , if ( is.na(staff.costs) ) staff.costs <- mean(staff.costs)
)

## ------------------------------------------------------------------------
data(validate::retailers)
ret1 <- modify(retailers,m)

## ----eval=FALSE----------------------------------------------------------
#  library(magrittr)
#  ret2 <- retailers %>% modifier(m)

## ----eval=FALSE----------------------------------------------------------
#  retailers %<>% modify_so(
#    if ( other.rev < 0) other.rev <- -1 * other.rev
#    , if ( is.na(staff.costs) ) staff.costs <- mean(staff.costs)
#  )

