library(testthat)
library(errorlocate)

test_check("errorlocate")
