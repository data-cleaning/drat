
setNames <- function(x,nm){
  names(x) <- nm
  x
}

