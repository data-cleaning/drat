
context("Syntax attributes")

test_that("validation syntax is recognized",{
  # fiets(x) is not a validation rule
  expect_warning(validator(fiets(x)))
  # we complain that the regular expression 'aap' cannot be matched 
  # since 'varlist' is not specified.
  #expect_warning( validator(G:{fiets; 'aap'})$exprs() )
})


test_that('Exception handling can be switched',{
  
  validate_options(raise='none')
  expect_equal(factory(function()stop('aap'), validate_options)()$err, 'aap')
  expect_equal(factory(function()warning('aap'), validate_options)()$warn, 'aap')
  
  validate_options(raise='errors')
  expect_error(factory(function() stop(), validate_options)())
  
  validate_options(raise = 'all')
  expect_error(factory(function() stop(),validate_options)())
  expect_warning(factory(function() warning(),validate_options)())
  
  validate_options('reset')
})


test_that('Missings are counted correctly',{
  d1 <- data.frame(x=1:3,y=4:6) 
  d2 <- data.frame(x=c(NA,2,NA),y=c(4,5,NA))
  expect_equal(evalq(number_missing(),d1),    0L)
  expect_equal(evalq(number_missing(),d2),    3L)
  expect_equal(evalq(number_missing(x),d2),   2L)
  expect_equal(evalq(number_missing(x,y),d2), 3L)
  expect_equal(evalq(number_missing("."),d2), 3L)  
  
  expect_equal(evalq(fraction_missing(),d1),    0/6)
  expect_equal(evalq(fraction_missing(),d2),    3/6)
  expect_equal(evalq(fraction_missing(x),d2),   2/3)
  expect_equal(evalq(fraction_missing(x,y),d2), 3/6)
  expect_equal(evalq(fraction_missing("."),d2), 3/6)  
  
  
  expect_equal(evalq(row_missing(),d1),    c(0L,0L,0L))
  expect_equal(evalq(row_missing(),d2),    c(1L,0L,2L))
  expect_equal(evalq(row_missing(x),d2),   c(1L,0L,1L))
  expect_equal(evalq(row_missing(x,y),d2), c(1L,0L,2L))
  expect_equal(evalq(row_missing("."),d2), c(1L,0L,2L))  
  
  expect_equal(evalq(col_missing(),d1),    c(x=0L,y=0L))
  expect_equal(evalq(col_missing(),d2),    c(x=2L,y=1L))
  expect_equal(evalq(col_missing(x),d2),   c(x=2L)     )
  expect_equal(evalq(col_missing(x,y),d2), c(x=2L,y=1L))
  expect_equal(evalq(col_missing("."),d2), c(x=2L,y=1L))  

  expect_equal(evalq(number_unique(),d1),3)
  expect_equal(evalq(any_duplicated(),d1),FALSE)
  
    
  expect_equal(evalq(any_missing(),d1), FALSE)
  expect_equal(evalq(any_missing("."),d1), FALSE)
  expect_equal(evalq(any_missing(),d2), TRUE)
  expect_equal(evalq(any_missing("."),d2), TRUE)
  expect_equal(evalq(any_missing(x),d2), TRUE)
  expect_equal(evalq(any_missing(x,y),d2), TRUE)
  
})


test_that("Functional dependencies", {
  v1 <- validator(stad + straat ~ postcode)
  dat <- data.frame(
    straat = c('kerkstraat','kerkstraat','kerkstraat','kerkstraat')
    ,stad = c('DH','DH','H','DH')
    ,postcode = c('2495','2496','8888','2495')
  )
  cf <- confront(dat,v1)
  expect_equivalent(values(cf),array(c(1,1,3,4),dim=c(4,1)))
})







