library(testthat)
test_check("validate.adjust")

