library(testthat)
library(validatetools)

test_check("validatetools")
